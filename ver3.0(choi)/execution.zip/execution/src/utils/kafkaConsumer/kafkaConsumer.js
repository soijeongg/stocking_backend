import { Kafka } from 'kafkajs';

const kafka = new Kafka({
  clientId: 'execution-server',
  brokers: ['localhost:9092'] // Kafka 브로커의 주소
});

const consumer = kafka.consumer({ groupId: 'execution-group' });

const runConsumer = async () => {
  // Consumer 연결
  await consumer.connect();
  
  // 특정 토픽 구독
  await consumer.subscribe({ topic: 'order-topic', fromBeginning: true });

  // 메시지 수신 및 처리
  await consumer.run({
    eachMessage: async ({ topic, partition, message }) => {
      const messageValue = message.value.toString();
      console.log(`Received message: ${messageValue}`);
      
      // 메시지 처리 로직
      // 예: 체결 처리
    },
  });
};

runConsumer().catch(console.error);
