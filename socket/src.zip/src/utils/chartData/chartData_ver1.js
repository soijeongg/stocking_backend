// import { WebSocketServer, WebSocket } from 'ws';
// import { parse } from 'cookie';
// import { prisma } from '../prisma/index.js';

// let wss;
// const clients = new Map();

// function setupWebSocketServer(server) {
//   wss = new WebSocketServer({ server });

//   wss.on('connection', function connection(ws, req) {
//     console.log('Client connected. Connected URL:', req.url);
//     // URL에서 경로와 companyId 분석
//     const path = req.url.split('/')[2];
//     const companyId = parseInt(req.url.split('/')[3], 10);

//     // 메시지 수신 시 처리
//     ws.on('message', function incoming(message) {
//       const data = JSON.parse(message);

//       // 백엔드 메인 서버로부터의 메시지 처리 (개인 메시지)
//       if (data.type === 'personal') {
//         console.log('체결 메세지 수신:', data.userId, ' ', data.notices);
//         // 특정 사용자에게 메시지 전송
//         const clientWs = clients.get(data.userId);
//         if (clientWs && clientWs.readyState === WebSocket.OPEN) {
//           clientWs.send(JSON.stringify({ type: 'notices', notices: data.notices }));
//         } else {
//           console.log(`Client ${data.userId} not found or connection is not open.`);
//         }
//       } else if (data.type === 'broadcast') {
//         // 모든 사용자에게 메시지 전송
//         console.log('전체 메세지 수신:', data.notices);
//         wss.clients.forEach((client) => {
//           if (client.readyState === WebSocket.OPEN) {
//             // 메시지 구성을 chatting.js가 처리할 수 있는 형식으로 변경
//             client.send(JSON.stringify({ type: 'notices', notices: data.notices }));
//           }
//         });
//       }

//       // 프론트엔드 클라이언트로부터의 요청 처리
//       if (path === 'chartData') {
//         fetchAndSendChartData(companyId, ws);
//       } else if (path === 'orderData') {
//         fetchAndSendOrderData(companyId, ws);
//       }
//     });

//     ws.on('close', () => {
//       console.log('Client disconnected');
//       clients.delete(ws);
//     });

//     // 프론트엔드 클라이언트 식별을 위해 userId와 WebSocket 인스턴스를 맵핑
//     const userId = getUserIdFromReq(req);
//     if (userId) {
//       clients.set(userId, ws);
//     }
//   });
// }

// // 차트 데이터 조회
// async function fetchAndSendChartData(companyId, ws) {
//   const price = await prisma.company.findFirst({
//     select: { currentPrice: true, initialPrice: true },
//     where: { companyId: +companyId },
//   });
//   ws.send(JSON.stringify({ type: 'chartData', data: price }));
// }

// // 호가 데이터 조회
// async function fetchAndSendOrderData(companyId, ws) {
//   let priceResult = await prisma.company.findFirst({
//     select: { currentPrice: true },
//     where: { companyId: +companyId },
//   });

//   if (priceResult) {
//     let currentPrice = priceResult.currentPrice;
//     let groupedOrders = await prisma.order.groupBy({
//       by: ['type', 'price'], // type과 price로 그룹화합니다.
//       where: {
//         companyId: +companyId,
//         price: {
//           gte: currentPrice - 50000, // 현재 가격 기준으로 -50000 이상
//           lte: currentPrice + 50000, // 현재 가격 기준으로 +50000 이하
//         },
//       },
//       _sum: {
//         quantity: true, // 각 그룹의 quantity 합계를 계산합니다.
//       },
//       having: {
//         quantity: {
//           _sum: {
//             gt: 0, // quantity 합계가 0보다 큰 그룹만 포함시킵니다.
//           },
//         },
//       },
//     });

//     // 가격에 따라 정렬 (판매 주문은 오름차순, 구매 주문은 내림차순)
//     groupedOrders.sort((a, b) => {
//       if (a.price === b.price) {
//         return a.type === 'sell' ? -1 : 1;
//       }
//       return b.price - a.price;
//     });

//     // 결과 전송
//     ws.send(JSON.stringify({ type: 'orderData', data: { groupedOrders, currentPrice } }));
//   } else {
//     console.log('Company not found or currentPrice is undefined');
//     ws.send(JSON.stringify({ type: 'orderData', data: { groupedOrders: [], currentPrice: null } })); // 오류 메시지 또는 빈 데이터 전송
//   }
// }

// function getUserIdFromReq(req) {
//   const cookies = parse(req.headers.cookie || '');
//   const sessionId = cookies['connect.sid'];
//   // 세션 스토어에서 세션 ID로 사용자 정보 조회 등
//   return sessionId;
// }

// export default setupWebSocketServer;
